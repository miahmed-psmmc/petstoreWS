package petstoreStepDefinitionClass;

import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
//import org.openqa.selenium.Keys;
//import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
//import org.openqa.selenium.firefox.FirefoxDriver;
//import org.openqa.selenium.ie.InternetExplorerDriver;
import cucumber.api.DataTable;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;
import cucumber.api.java.en.Then;

public class petstoreStepDefinitionClass {
	private static WebDriver driver = null;
	@Given("^I open my application$")
	public void I_open_my_application() throws Exception {
// 		SWITCH TO FRIEFOX BROWSER 
//		WebDriver driver = new FirefoxDriver();
//		SWITCH TO INTERNET EXPLORER
//		System.setProperty("webdriver.ie.driver", "D:\\petstoreWS\\PetstoreSwagger\\Jars\\IEDriverServer.exe");
//		WebDriver driver = new InternetExplorerDriver();
//		SWITCH TO GOOGLE CHROME
		System.setProperty("webdriver.chrome.driver", "D:\\petstoreWS\\PetstoreSwagger\\Jars\\chromedriver.exe");
		driver = new ChromeDriver();
//		LAUNCHING WEBSITE
		driver.get("http://petstore.swagger.io/#/");
		driver.manage().timeouts().pageLoadTimeout(10000, TimeUnit.MILLISECONDS);
		driver.manage().window().maximize();
	}
	
	@When("^I upload an image$")
	public void I_upload_an_image(DataTable dt) throws Exception {
		List<Map<String, String>> list = dt.asMaps(String.class, String.class);
		WebElement _clickAuthorize;
		_clickAuthorize = driver.findElement(By.xpath("//span[.='Authorize']"));
		_clickAuthorize.click();
		Thread.sleep(2500);
		driver.findElements(By.cssSelector("input[type='text']")).get(1).sendKeys(list.get(0).get("Auth_Key"));
/*		WebElement _clickAuthorizeBtn;
		_clickAuthorizeBtn = driver.findElement(By.xpath("//button[@class='btn modal-btn auth authorize button' and @id='Authorize']"));
		_clickAuthorizeBtn.click();
*/
		WebElement _authorize;
		_authorize = driver.findElement(By.xpath("//button[@class='btn modal-btn auth authorize button']"));
		_authorize.click();

/*		WebElement _clickClose;
		_clickClose = driver.findElement(By.xpath("//span[.='Close']"));
		_clickClose.click();
*/
		WebElement _close;
		_close = driver.findElement(By.xpath("//button[@class='btn modal-btn auth btn-done button']"));
		_close.click();
		WebElement _uploadImage;
		_uploadImage = driver.findElement(By.id("operations-pet-uploadFile"));
		_uploadImage.click();
		WebElement _tryItOut1;
		_tryItOut1 = driver.findElement(By.className("try-out"));
		_tryItOut1.click();

		driver.findElements(By.cssSelector("input[type='text']")).get(1).sendKeys(list.get(0).get("Pet_ID"));
		driver.findElements(By.cssSelector("input[type='text']")).get(2).sendKeys(list.get(0).get("Additional_Data"));
		/*
		driver.findElements(By.cssSelector("input[type='text']")).get(1).sendKeys("0123456789");
		driver.findElements(By.cssSelector("input[type='text']")).get(2).sendKeys("Additional info of the Pet.");*/
		WebElement _uploadImageExecute;
		_uploadImageExecute = driver.findElement(By.className("execute-wrapper"));
		_uploadImageExecute.click();
		Thread.sleep(2500);
	}
	
	@And("^I add a new pet to the store$")
	public void I_add_a_new_pet_to_the_store() throws Exception {
		WebElement _addPet;
		_addPet = driver.findElement(By.id("operations-pet-addPet"));
		_addPet.click();
		driver.findElements(By.className("try-out")).get(1).click();
		driver.manage().timeouts().pageLoadTimeout(10000, TimeUnit.MILLISECONDS);
		driver.findElements(By.className("execute-wrapper")).get(0).click();
	}
		
	@When("^I update an existing Pet$")
	public void I_update_an_existing_Pet() throws Exception {
		WebElement _updatePet;
		_updatePet = driver.findElement(By.id("operations-pet-updatePet"));
		_updatePet.click();
		driver.findElements(By.className("try-out")).get(2).click();
		driver.manage().timeouts().pageLoadTimeout(10000, TimeUnit.MILLISECONDS);
		driver.findElements(By.className("execute-wrapper")).get(0).click();
	}
	
	@Then("^I logoff and close browser$")
	public void I_logoff_and_close_browser() throws Exception {
		WebElement _clickAuthorize;
		_clickAuthorize = driver.findElement(By.xpath("//span[.='Authorize']"));
		_clickAuthorize.click();
		WebElement _close;
		_close = driver.findElement(By.xpath("//button[@class='btn modal-btn auth btn-done button']"));
		_close.click();
		driver.quit();
	}	
}